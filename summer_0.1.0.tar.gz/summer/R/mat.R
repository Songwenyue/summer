matri<-function(maxtri1,maxtri2,num,nrow,ncol)
{
  for(i in 1:nrow)
  {
    for(j in 1:ncol)
    {
      if(num==1)
        matri1[i,j]<-matri1[i,j]+matri2[i,j]
      if(num3==2)
        matri1[i,j]<-matri1[i,j]-matri2[i,j]
      if(num3==3)
        matri1[i,j]<-matri1[i,j]*matri2[i,j]
      if(num3==4)
        matri1[i,j]<-matri1[i,j]/matri2[i,j]
      if(num3==5)
        matri1[i,j]<-matri1[i,j]%%matri2[i,j]
    }
  }
  return(matrix1)
}
