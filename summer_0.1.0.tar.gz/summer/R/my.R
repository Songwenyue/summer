
my<-function(data)  #设置参数data，用于存储矩阵
{
  nc<-ncol(data)    #计算矩阵有多少列
  nr<-nrow(data)    #计算矩阵有多少行
  d<-c(nrow,ncol)    #设置一个矩阵存储
  for(i in 1:nc){    #循环参数
    for (j in 1:nr) {
      if(d[j,i]%%2==1)  d[j,i]=1  #是奇数就换成1
      else  d[j,i]=0      #偶数换成0

    }
  }
  d
}
